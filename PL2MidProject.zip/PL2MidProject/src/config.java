import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class config {
    public static String[] getGroupsList(){
            BufferedReader reader = null;
            String[] groupslist = new String[10];
            try {
                File file = new File("config.db");
                reader = new BufferedReader(new FileReader(file));
                String lie;
                reader = new BufferedReader(new FileReader(file));
                String[] ginfo;
                while ((lie = reader.readLine()) != null) {
                    ginfo = lie.split("%");
                    groupslist[0] = "Choose a group";
                    int i = 1;
                    for(String info: ginfo){
                        groupslist[i] = info;
                        i++;
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        return groupslist;
    }
}
