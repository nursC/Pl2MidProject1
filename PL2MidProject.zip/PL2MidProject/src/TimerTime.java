import java.util.Timer;
import java.util.TimerTask;

public class TimerTime {
    private int times;
    private questions display;

    public TimerTime(final questions main, int time){
        this.display = main;
        this.times = time * 60;
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (times == 0) {
                    timer.cancel();
                    display.autoSubmit();
                }
                times--;
                display.timerOut.setText(getTime());
            }
            }, 1000, 1000);
    }

    public String getTime() {
        int minutes;
        minutes = times / 60;
        int second;
        second = times % 60;
        return minutes + " : " + second;
    }
}
